CREATE DATABASE eyewear_db;
-- After creating the database, connect to eyewear_db in pgAdmin and run the remaining statements.

CREATE TABLE IF NOT EXISTS products (
    product_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    category VARCHAR(40) NOT NULL CHECK (category IN ('Eyeglasses', 'Sunglasses', 'Sports')),
    price NUMERIC(10,2) NOT NULL CHECK (price >= 0),
    stock INTEGER NOT NULL DEFAULT 10 CHECK (stock >= 0),
    description VARCHAR(250)
);

CREATE TABLE IF NOT EXISTS customers (
    customer_id SERIAL PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS orders (
    order_id SERIAL PRIMARY KEY,
    customer_id INTEGER NOT NULL REFERENCES customers(customer_id),
    order_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    total_amount NUMERIC(10,2) NOT NULL CHECK (total_amount >= 0)
);

CREATE TABLE IF NOT EXISTS order_items (
    order_item_id SERIAL PRIMARY KEY,
    order_id INTEGER NOT NULL REFERENCES orders(order_id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(product_id),
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    unit_price NUMERIC(10,2) NOT NULL CHECK (unit_price >= 0)
);

INSERT INTO products (name, category, price, stock, description) VALUES
('Urban Square', 'Eyeglasses', 185.00, 15, 'Minimal square frame'),
('Aqua Lens', 'Eyeglasses', 195.00, 12, 'Lightweight aqua frame'),
('Safety Shield', 'Sports', 210.00, 10, 'Protective wrap-around eyewear'),
('Cat Eye Noir', 'Eyeglasses', 225.00, 8, 'Bold cat-eye design'),
('Rose Glow', 'Sunglasses', 240.00, 9, 'Rose-tinted fashion sunglasses'),
('Gold Aviator', 'Sunglasses', 260.00, 11, 'Classic aviator style')
ON CONFLICT (name) DO NOTHING;

-- Report queries for the DBMS micro-project
-- 1. Products and current stock
SELECT product_id, name, category, price, stock FROM products ORDER BY name;
-- 2. Total revenue from completed orders
SELECT COALESCE(SUM(total_amount), 0) AS total_revenue FROM orders;
-- 3. Best-selling products
SELECT p.name, COALESCE(SUM(oi.quantity), 0) AS units_sold
FROM products p LEFT JOIN order_items oi ON p.product_id = oi.product_id
GROUP BY p.product_id, p.name ORDER BY units_sold DESC;
-- 4. Low-stock products
SELECT name, stock FROM products WHERE stock <= 5 ORDER BY stock;
-- 5. Customer order history
SELECT c.full_name, o.order_id, o.order_date, o.total_amount
FROM customers c JOIN orders o ON c.customer_id = o.customer_id ORDER BY o.order_date DESC;
