package com.eyewear;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class App extends JFrame {
    private final JPanel productPanel = new JPanel(new GridLayout(0, 3, 14, 14));
    private final DefaultListModel<String> cartModel = new DefaultListModel<>();
    private final JList<String> cartList = new JList<>(cartModel);
    private final JLabel totalLabel = new JLabel("Total: ₹0.00");
    private final JTextField searchField = new JTextField(18);
    private final Map<Integer, Integer> cart = new LinkedHashMap<>();
    private List<Database.Product> products = new ArrayList<>();

    public App() {
        super("Eyewear Boutique — DBMS Micro Project");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1050, 700);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(246, 248, 250));
        setLayout(new BorderLayout(14, 14));

        JPanel top = new JPanel(new BorderLayout(12, 8));
        top.setBorder(new EmptyBorder(14, 18, 4, 18));
        top.setOpaque(false);
        JLabel title = new JLabel("Premium Eyewear Collection");
        title.setFont(new Font("SansSerif", Font.BOLD, 26));
        title.setForeground(new Color(30, 70, 120));
        top.add(title, BorderLayout.NORTH);
        JPanel search = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); search.setOpaque(false);
        search.add(new JLabel("Search:")); search.add(searchField);
        JButton find = new JButton("Search"); find.addActionListener(e -> loadProducts()); search.add(find);
        JButton all = new JButton("Show All"); all.addActionListener(e -> {searchField.setText("");loadProducts();}); search.add(all);
        top.add(search, BorderLayout.SOUTH);
        add(top, BorderLayout.NORTH);

        productPanel.setBorder(new EmptyBorder(8, 18, 18, 8));
        productPanel.setBackground(new Color(246, 248, 250));
        JScrollPane productScroll = new JScrollPane(productPanel);
        productScroll.setBorder(BorderFactory.createEmptyBorder());
        add(productScroll, BorderLayout.CENTER);

        JPanel right = new JPanel(new BorderLayout(8, 10)); right.setPreferredSize(new Dimension(285, 0));
        right.setBorder(new EmptyBorder(8, 4, 18, 18)); right.setOpaque(false);
        JLabel cartTitle = new JLabel("Your Cart"); cartTitle.setFont(new Font("SansSerif", Font.BOLD, 20));
        right.add(cartTitle, BorderLayout.NORTH);
        cartList.setVisibleRowCount(12); right.add(new JScrollPane(cartList), BorderLayout.CENTER);
        JPanel bottom = new JPanel(new GridLayout(0,1,6,6)); bottom.setOpaque(false);
        totalLabel.setFont(new Font("SansSerif", Font.BOLD, 17)); bottom.add(totalLabel);
        JButton remove = new JButton("Remove Selected"); remove.addActionListener(e -> removeSelected()); bottom.add(remove);
        JButton checkout = new JButton("Checkout / Save Order"); checkout.addActionListener(e -> checkout()); bottom.add(checkout);
        JButton manage = new JButton("Manage Products (CRUD)"); manage.addActionListener(e -> manageProducts()); bottom.add(manage);
        JButton reports = new JButton("Sales Reports"); reports.addActionListener(e -> showReports()); bottom.add(reports);
        right.add(bottom, BorderLayout.SOUTH);
        add(right, BorderLayout.EAST);
        loadProducts();
    }

    private void loadProducts() {
        try {
            products = Database.getProducts(searchField.getText());
            productPanel.removeAll();
            for (Database.Product p : products) productPanel.add(productCard(p));
            productPanel.revalidate(); productPanel.repaint();
        } catch (SQLException ex) { showDbError(ex); }
    }

    private JPanel productCard(Database.Product p) {
        JPanel card = new JPanel(new BorderLayout(8, 8));
        card.setBackground(Color.WHITE); card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 226, 232)), new EmptyBorder(12, 12, 12, 12)));
        JLabel artwork = new JLabel(frameIcon(p.category()), SwingConstants.CENTER);
        artwork.setOpaque(true); artwork.setBackground(new Color(232, 239, 244)); artwork.setPreferredSize(new Dimension(190, 100));
        card.add(artwork, BorderLayout.NORTH);
        JPanel details = new JPanel(new GridLayout(0,1,3,3)); details.setOpaque(false);
        JLabel name = new JLabel(p.name()); name.setFont(new Font("SansSerif", Font.BOLD, 16));
        details.add(name); details.add(new JLabel(p.category())); details.add(new JLabel("₹" + p.price().toPlainString()));
        details.add(new JLabel("Stock: " + p.stock()));
        JTextArea desc = new JTextArea(p.description()); desc.setLineWrap(true); desc.setWrapStyleWord(true); desc.setEditable(false); desc.setOpaque(false); desc.setFont(new Font("SansSerif", Font.PLAIN, 12)); details.add(desc);
        card.add(details, BorderLayout.CENTER);
        JButton add = new JButton("Add to Cart"); add.setEnabled(p.stock() > 0); add.addActionListener(e -> {cart.merge(p.id(),1,Integer::sum); refreshCart();});
        card.add(add, BorderLayout.SOUTH);
        return card;
    }

    private Icon frameIcon(String category) {
        return new Icon() {
            public int getIconWidth(){return 145;} public int getIconHeight(){return 70;}
            public void paintIcon(Component c, Graphics g, int x, int y) {
                Graphics2D g2=(Graphics2D)g.create(); g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setStroke(new BasicStroke(4)); g2.setColor(category.equals("Sunglasses")?new Color(42,54,68):new Color(74,112,132));
                g2.drawRoundRect(x+10,y+20,52,32,10,10); g2.drawRoundRect(x+83,y+20,52,32,10,10); g2.drawLine(x+62,y+31,x+83,y+31); g2.drawLine(x+10,y+25,x+2,y+18); g2.drawLine(x+135,y+25,x+143,y+18);
                if(category.equals("Sunglasses")){g2.setColor(new Color(85,115,122,150));g2.fillRoundRect(x+13,y+23,46,26,8,8);g2.fillRoundRect(x+86,y+23,46,26,8,8);} g2.dispose();
            }
        };
    }

    private void refreshCart() {
        cartModel.clear(); BigDecimal total=BigDecimal.ZERO;
        for (Map.Entry<Integer,Integer> entry:cart.entrySet()) {
            Database.Product p=products.stream().filter(x->x.id()==entry.getKey()).findFirst().orElse(null);
            if(p==null) { try { p=Database.getProducts("").stream().filter(x->x.id()==entry.getKey()).findFirst().orElse(null); } catch(SQLException ignored){} }
            if(p!=null){cartModel.addElement(p.name()+" x "+entry.getValue()+" — ₹"+p.price().multiply(BigDecimal.valueOf(entry.getValue())));total=total.add(p.price().multiply(BigDecimal.valueOf(entry.getValue())));}
        }
        totalLabel.setText("Total: ₹"+total.setScale(2,java.math.RoundingMode.HALF_UP));
    }

    private void removeSelected() {
        int index=cartList.getSelectedIndex(); if(index<0)return;
        int i=0; Integer idToRemove=null;
        for(Integer id:cart.keySet()){if(i++==index){idToRemove=id;break;}}
        if(idToRemove!=null)cart.remove(idToRemove); refreshCart();
    }

    private void checkout() {
        if(cart.isEmpty()){JOptionPane.showMessageDialog(this,"Your cart is empty.");return;}
        JTextField name=new JTextField(), email=new JTextField(), phone=new JTextField();
        JPanel form=new JPanel(new GridLayout(0,2,8,8)); form.add(new JLabel("Full name:*"));form.add(name);form.add(new JLabel("Email:*"));form.add(email);form.add(new JLabel("Phone:"));form.add(phone);
        if(JOptionPane.showConfirmDialog(this,form,"Customer Details",JOptionPane.OK_CANCEL_OPTION)!=JOptionPane.OK_OPTION)return;
        if(name.getText().isBlank()||email.getText().isBlank()||!email.getText().contains("@")){JOptionPane.showMessageDialog(this,"Enter a name and valid email.");return;}
        List<Database.CartLine> lines=new ArrayList<>();
        try { List<Database.Product> latest=Database.getProducts(""); for(Map.Entry<Integer,Integer> e:cart.entrySet()){Database.Product p=latest.stream().filter(x->x.id()==e.getKey()).findFirst().orElseThrow();lines.add(new Database.CartLine(p,e.getValue()));}
            Database.checkout(name.getText().trim(),email.getText().trim(),phone.getText().trim(),lines);
            JOptionPane.showMessageDialog(this,"Order saved successfully to PostgreSQL.");cart.clear();refreshCart();loadProducts();
        } catch(Exception ex){showDbError(ex);}
    }

    private void manageProducts() {
        String[] choices={"Add product","Update product","Delete product","Cancel"};
        int action=JOptionPane.showOptionDialog(this,"Choose a product operation.","Product Management",JOptionPane.DEFAULT_OPTION,JOptionPane.PLAIN_MESSAGE,null,choices,choices[0]);
        if(action==0) editProduct(null);
        else if(action==1){Database.Product p=chooseProduct();if(p!=null)editProduct(p);}
        else if(action==2){Database.Product p=chooseProduct();if(p!=null&&JOptionPane.showConfirmDialog(this,"Delete "+p.name()+"?","Confirm",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION)try{Database.deleteProduct(p.id());loadProducts();}catch(SQLException ex){showDbError(ex);}}
    }

    private Database.Product chooseProduct() {
        try {List<Database.Product> all=Database.getProducts("");if(all.isEmpty())return null;Object choice=JOptionPane.showInputDialog(this,"Select product:","Products",JOptionPane.PLAIN_MESSAGE,null,all.stream().map(p->p.id()+" — "+p.name()).toArray(),null);if(choice==null)return null;int id=Integer.parseInt(choice.toString().split(" — ")[0]);return all.stream().filter(p->p.id()==id).findFirst().orElse(null);}catch(Exception ex){showDbError(ex);return null;}
    }

    private void editProduct(Database.Product p) {
        JTextField name=new JTextField(p==null?"":p.name()); JComboBox<String> category=new JComboBox<>(new String[]{"Eyeglasses","Sunglasses","Sports"});if(p!=null)category.setSelectedItem(p.category());
        JTextField price=new JTextField(p==null?"":p.price().toPlainString()),stock=new JTextField(p==null?"10":String.valueOf(p.stock())),desc=new JTextField(p==null?"":p.description());
        JPanel form=new JPanel(new GridLayout(0,2,8,8));form.add(new JLabel("Name:"));form.add(name);form.add(new JLabel("Category:"));form.add(category);form.add(new JLabel("Price:"));form.add(price);form.add(new JLabel("Stock:"));form.add(stock);form.add(new JLabel("Description:"));form.add(desc);
        if(JOptionPane.showConfirmDialog(this,form,p==null?"Add Product":"Update Product",JOptionPane.OK_CANCEL_OPTION)!=JOptionPane.OK_OPTION)return;
        try{BigDecimal amount=new BigDecimal(price.getText().trim());int qty=Integer.parseInt(stock.getText().trim());if(name.getText().isBlank()||amount.signum()<0||qty<0)throw new IllegalArgumentException("Enter a name, non-negative price, and non-negative stock.");Database.saveProduct(p==null?null:p.id(),name.getText().trim(),(String)category.getSelectedItem(),amount,qty,desc.getText().trim());loadProducts();}
        catch(Exception ex){JOptionPane.showMessageDialog(this,"Could not save product: "+ex.getMessage(),"Input/Database Error",JOptionPane.ERROR_MESSAGE);}
    }

    private void showReports(){try{JTextArea text=new JTextArea(Database.reports(),20,38);text.setEditable(false);JOptionPane.showMessageDialog(this,new JScrollPane(text),"Database Reports",JOptionPane.INFORMATION_MESSAGE);}catch(SQLException ex){showDbError(ex);}}
    private void showDbError(Exception ex){JOptionPane.showMessageDialog(this,"Database operation failed. Check PostgreSQL is running, eyewear_db exists, and connection settings are correct.\n\nDetails: "+ex.getMessage(),"Database Error",JOptionPane.ERROR_MESSAGE);}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
            catch(Exception ignored){}
            try { Database.ensureSeedData(); }
            catch(SQLException ex){JOptionPane.showMessageDialog(null,"Could not connect to PostgreSQL. Create the database/tables using sql/eyewear_db.sql and check the DB password.\n\n"+ex.getMessage(),"Database Setup",JOptionPane.ERROR_MESSAGE);}
            new App().setVisible(true);
        });
    }
}
