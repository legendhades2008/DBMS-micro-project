package com.eyewear;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public final class Database {
    private static final String URL = System.getenv().getOrDefault("EYEWEAR_DB_URL", "jdbc:postgresql://localhost:5432/eyewear_db");
    private static final String USER = System.getenv().getOrDefault("EYEWEAR_DB_USER", "postgres");
    private static final String PASSWORD = System.getenv().getOrDefault("EYEWEAR_DB_PASSWORD", "postgres");
    private Database() {}

    public static Connection connect() throws SQLException { return DriverManager.getConnection(URL, USER, PASSWORD); }

    public static void ensureSeedData() throws SQLException {
        String sql = "INSERT INTO products(name,category,price,stock,description) VALUES(?,?,?,?,?) ON CONFLICT(name) DO NOTHING";
        Object[][] rows = {
            {"Urban Square", "Eyeglasses", 185.00, 15, "Minimal square frame"},
            {"Aqua Lens", "Eyeglasses", 195.00, 12, "Lightweight aqua frame"},
            {"Safety Shield", "Sports", 210.00, 10, "Protective wrap-around eyewear"},
            {"Cat Eye Noir", "Eyeglasses", 225.00, 8, "Bold cat-eye design"},
            {"Rose Glow", "Sunglasses", 240.00, 9, "Rose-tinted fashion sunglasses"},
            {"Gold Aviator", "Sunglasses", 260.00, 11, "Classic aviator style"}
        };
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            for (Object[] r : rows) { ps.setString(1,(String)r[0]); ps.setString(2,(String)r[1]); ps.setDouble(3,(double)r[2]); ps.setInt(4,(int)r[3]); ps.setString(5,(String)r[4]); ps.addBatch(); }
            ps.executeBatch();
        }
    }

    public static List<Product> getProducts(String search) throws SQLException {
        List<Product> out = new ArrayList<>();
        String sql = "SELECT product_id,name,category,price,stock,COALESCE(description,'') FROM products WHERE LOWER(name) LIKE LOWER(?) OR LOWER(category) LIKE LOWER(?) ORDER BY product_id";
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            String q = "%" + (search == null ? "" : search.trim()) + "%"; ps.setString(1,q); ps.setString(2,q);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) out.add(new Product(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getBigDecimal(4),rs.getInt(5),rs.getString(6))); }
        }
        return out;
    }

    public static void saveProduct(Integer id, String name, String category, BigDecimal price, int stock, String description) throws SQLException {
        String sql = id == null ? "INSERT INTO products(name,category,price,stock,description) VALUES(?,?,?,?,?)" : "UPDATE products SET name=?,category=?,price=?,stock=?,description=? WHERE product_id=?";
        try (Connection c=connect(); PreparedStatement ps=c.prepareStatement(sql)) {
            ps.setString(1,name); ps.setString(2,category); ps.setBigDecimal(3,price); ps.setInt(4,stock); ps.setString(5,description);
            if(id!=null) ps.setInt(6,id); ps.executeUpdate();
        }
    }

    public static void deleteProduct(int id) throws SQLException {
        try (Connection c=connect(); PreparedStatement ps=c.prepareStatement("DELETE FROM products WHERE product_id=? AND product_id NOT IN (SELECT product_id FROM order_items)")) {
            ps.setInt(1,id); if(ps.executeUpdate()==0) throw new SQLException("Product is used in an order, or it no longer exists.");
        }
    }

    public static void checkout(String name, String email, String phone, List<CartLine> cart) throws SQLException {
        if (cart.isEmpty()) throw new SQLException("Your cart is empty.");
        try (Connection c=connect()) {
            c.setAutoCommit(false);
            try {
                int customerId;
                try (PreparedStatement ps=c.prepareStatement("INSERT INTO customers(full_name,email,phone) VALUES(?,?,?) ON CONFLICT(email) DO UPDATE SET full_name=EXCLUDED.full_name, phone=EXCLUDED.phone RETURNING customer_id")) {
                    ps.setString(1,name); ps.setString(2,email); ps.setString(3,phone);
                    try(ResultSet rs=ps.executeQuery()){rs.next(); customerId=rs.getInt(1);}
                }
                BigDecimal total=BigDecimal.ZERO;
                for(CartLine line:cart) total=total.add(line.product.price().multiply(BigDecimal.valueOf(line.quantity)));
                int orderId;
                try(PreparedStatement ps=c.prepareStatement("INSERT INTO orders(customer_id,total_amount) VALUES(?,?) RETURNING order_id")){
                    ps.setInt(1,customerId); ps.setBigDecimal(2,total); try(ResultSet rs=ps.executeQuery()){rs.next();orderId=rs.getInt(1);}
                }
                try(PreparedStatement check=c.prepareStatement("SELECT stock,price FROM products WHERE product_id=? FOR UPDATE");
                    PreparedStatement item=c.prepareStatement("INSERT INTO order_items(order_id,product_id,quantity,unit_price) VALUES(?,?,?,?)");
                    PreparedStatement update=c.prepareStatement("UPDATE products SET stock=stock-? WHERE product_id=?")) {
                    for(CartLine line:cart){
                        check.setInt(1,line.product.id()); int stock; BigDecimal price;
                        try(ResultSet rs=check.executeQuery()){if(!rs.next()) throw new SQLException("A product was removed. Refresh the product list."); stock=rs.getInt(1); price=rs.getBigDecimal(2);}
                        if(stock<line.quantity) throw new SQLException("Not enough stock for " + line.product.name());
                        item.setInt(1,orderId); item.setInt(2,line.product.id()); item.setInt(3,line.quantity); item.setBigDecimal(4,price); item.executeUpdate();
                        update.setInt(1,line.quantity); update.setInt(2,line.product.id()); update.executeUpdate();
                    }
                }
                c.commit();
            } catch(Exception ex){c.rollback(); if(ex instanceof SQLException se) throw se; throw new SQLException(ex);}
            finally {c.setAutoCommit(true);}
        }
    }

    public static String reports() throws SQLException {
        StringBuilder b=new StringBuilder("SALES SUMMARY\n");
        try(Connection c=connect(); Statement st=c.createStatement(); ResultSet rs=st.executeQuery("SELECT COUNT(*),COALESCE(SUM(total_amount),0) FROM orders")){
            rs.next(); b.append("Orders: ").append(rs.getInt(1)).append("\nRevenue: ₹").append(rs.getBigDecimal(2)).append("\n\nBEST-SELLING PRODUCTS\n");
        }
        try(Connection c=connect(); Statement st=c.createStatement(); ResultSet rs=st.executeQuery("SELECT p.name,COALESCE(SUM(i.quantity),0) sold FROM products p LEFT JOIN order_items i ON p.product_id=i.product_id GROUP BY p.product_id,p.name ORDER BY sold DESC,p.name")){
            while(rs.next()) b.append(rs.getString(1)).append(" — ").append(rs.getInt(2)).append(" sold\n");
        }
        b.append("\nLOW STOCK (5 OR LESS)\n");
        try(Connection c=connect(); Statement st=c.createStatement(); ResultSet rs=st.executeQuery("SELECT name,stock FROM products WHERE stock<=5 ORDER BY stock")){
            boolean any=false; while(rs.next()){any=true;b.append(rs.getString(1)).append(" — ").append(rs.getInt(2)).append(" left\n");} if(!any)b.append("No low-stock products.\n");
        }
        return b.toString();
    }

    public record Product(int id, String name, String category, BigDecimal price, int stock, String description) {}
    public record CartLine(Product product, int quantity) {}
}
