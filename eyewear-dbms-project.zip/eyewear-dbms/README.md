# Eyewear Boutique — DBMS Micro Project

This is a source-based JDBC/PostgreSQL version of the uploaded Eyewear Boutique Swing application. It keeps the core eyewear catalogue/cart idea and adds persistent products, customer/order storage, stock updates, CRUD operations, search, and reports.

## Requirements
- JDK 17 or later
- PostgreSQL and pgAdmin 4
- Maven

## 1. Create the database
1. Open pgAdmin and connect to your PostgreSQL server.
2. Open Query Tool on the default `postgres` database and run only `CREATE DATABASE eyewear_db;` from `sql/eyewear_db.sql` (or create it through the UI).
3. Select/connect to `eyewear_db`, open Query Tool, and run the rest of `sql/eyewear_db.sql`.

The SQL file contains sample eyewear products and report queries. If you execute it as one script, skip the `CREATE DATABASE eyewear_db;` line when already connected to `eyewear_db`, because PostgreSQL cannot create a database inside a transaction/query batch.

## 2. Set database credentials
Defaults in `Database.java` are URL `jdbc:postgresql://localhost:5432/eyewear_db`, user `postgres`, password `postgres`. Change the password default to your local PostgreSQL password, or set environment variables:
- `EYEWEAR_DB_URL`
- `EYEWEAR_DB_USER`
- `EYEWEAR_DB_PASSWORD`

Do not submit your real database password in the project report.

## 3. Run the application
Open a terminal in this folder and run:

```bash
mvn clean compile exec:java
```

Maven downloads the PostgreSQL JDBC driver through the dependency declared in `pom.xml`.

## Included features
- Search product by name/category
- Read products from PostgreSQL
- Add/update/delete products (delete is prevented when a product has order history)
- Shopping cart and checkout
- Store customer, order and order-item rows transactionally
- Decrease stock when an order succeeds; rollback if checkout fails
- Sales summary, best-selling products and low-stock report

## Main tables and relationships
- `customers (customer_id PK)` 1-to-many `orders (order_id PK, customer_id FK)`
- `orders` 1-to-many `order_items (order_item_id PK, order_id FK)`
- `products (product_id PK)` 1-to-many `order_items (product_id FK)`

For submission, include your ER diagram, relational mapping, screenshots of CRUD/search/checkout/reports, and example SELECT/JOIN/GROUP BY/HAVING queries.
